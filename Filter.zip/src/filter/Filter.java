/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filter;
import java.io.FilterReader;
import java.io.PushbackReader;
import java.io.Reader;
import java.io.StringReader;

/**
 *
 * @author alfon
 */
public class Filter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception  {
        // TODO code application logic here
        Reader r = new StringReader("ABCDEF");  
        FilterReader fr = new FilterReader(r){};
        int i = 0;
        char c;
      /**
       * entra en el while siempre y cuando sea distino de -1 y lo guarda en i 
       * cuando entra hace un castin del numero i a char e imprime por pantalla la letra que corresponde
       * 
       */
        try {
           // lee hasta el final se la frase
           while((i = fr.read())!=-1) {

              // convconvierte un integer en un char
              c = (char)i;
              System.out.println("Character read: "+c);
           }

        } catch(Exception e) {
           e.printStackTrace();
        } finally {
           if(r!=null)
              r.close();
           if(fr!=null)
              fr.close();
        }
    }
}