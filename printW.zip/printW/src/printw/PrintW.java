/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package printw;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

/**
 *
 * @author Samuel Osuna Alcaide
 */
public class PrintW {

    //La clase PrintWriter te permite escribir,por ejemplo, en un archivo.
    private static PrintWriter archivo;
    
    //Crea un nuevo archivo en el que escribe "Este es un archivo de prueba".
    public static void main(String[] args) {
    archivo.println("Este es un archivo de prueba");
    
    
    //Métodos
    //append introduce caracteres y secuencias de caracteres
    String s="Hola Mundo";
    PrintWriter pw = new PrintWriter(System.out);
    pw.append(s);
    
    //checkError() booleano que vacía la transmisión si esta no está cerrada, devuelve true si hay un error.
    System.out.println("" + pw.checkError());
    
    //flush() vacía la transmisión
    pw.flush();
    
    //format() escribe una cadena de caracteres con formato, se usa poniendo el formato y la cadena de caracteres.
    pw.format(Locale.ENGLISH, "Hello World");
    
    //print() imprime distintos tipos de objetos. El primer ejemplo de esta clase sirve como ejemplo del propio método.
    archivo.print("Prueba");
    
    //println() imprime distintos tipos de objetos y luego termina la línea.
    archivo.println("Prueba1");
    
    //Write() escribe un caracter o un String
    archivo.write("Escribe");
    
    //close() cierra la transmisión
    pw.close();
    archivo.close();
    }
    
    public PrintW() throws IOException {
        this.archivo = new PrintWriter(new FileWriter("archivoSalida.txt"));
    }
    
    
}
