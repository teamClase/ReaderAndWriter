/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chararraywriterandreader;

import java.io.CharArrayWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author juans
 */
public class MyCharArrayWriter {
    /*
    *  La clase CharArrayWriter puede ser usada para escribir datos en multiples ficheros.
    *  Esta clase extiende de la clase superior Writer.
    *  Posee un buffer que va creciendo automaticamente cuando se van escribiendo datos.
    *  El metodo close() no tiene efecto en esta clase.
    */
    public static void main(String[] args) {
        try{
        
        /*
        *  En este ejemplo voy a escribir una secuencioa de caracteres en 4 ficheros distintos
        *  Se instancia de dos posibles formas, por defecto como yo lo utilizo o dandole un tamaño inicial de buffer.
        */
        CharArrayWriter myCharArray = new CharArrayWriter();
        /*
        *  El tamaño por defecto es 0
        */
        System.out.println("El tamaño inicial por defecto es: "+myCharArray.size());
        /*
        *  Con el metodo .write() podemos escribir en su propio buffer un caracter identificado por un entero,
        *  un String o parte de el o un array de caracteres o parte de el
        *
        *  Cada vez que llamamos a .write() lo que hace es añadir al buffer.
        */
        int myChar = 65; //Es la A
        myCharArray.write(myChar);
        System.out.println("El entero "+myChar+" representa al caracter "+myCharArray.toString());
        
        String myString = " - Esta clase de java no se utiliza para nada";
        myCharArray.write(myString);
        System.out.println(myCharArray.toString());
        
        /*
        * en esta forma el primer numero indica desde donde escribe y el segundo numero indica CUANTOS caracteres LEE, NO HASTA DONDE.
        */
        myCharArray.write(myString, 0, 13); // " - Esta clase"
        myCharArray.write(myString, 35, 10); // " para nada"
        System.out.println(myCharArray.toString());
        
        char[] myarray = {' ','-',' ','z','y','x','w','v'};
        myCharArray.write(myarray);
        
        /*
        *  Al igual que con el String, el primer numero representa donde comienza a leer y el segundo cuantos caracteres del array leer
        */
        System.out.println(myCharArray.toString());
        myCharArray.write(myarray, 0, 5); // ' ','-',' ','z','y'
        System.out.println(myCharArray.toString());
        
        /*
        *  Para escribir en el buffer, tambien tenemos el metodo .append() con el que añadir una secuencia o parte de ella, o los cuatro caracteres NULL si la secuencia es nula
        *  Una secuencia puede ser un String, StringBuffer, StringBuilder o un CharBuffer pues todas ellas son clases implementadas de CharSequence
        */
        
        /*
        *  Ahora, con el buffer cargado de caracteres, escribimos varios ficheros con el mismo objeto CharArrayWriter haciendo uso del metodo .writeTo()
        *  Asi podemos escribir todo tipo de ficheros que sean soportados
        */
            System.out.println("El tamaño actual es de: "+myCharArray.size());
            FileWriter a;
            myCharArray.writeTo(a=new FileWriter("PrimerFichero.txt"));
            FileWriter b;
            myCharArray.writeTo(b=new FileWriter("SegundoFichero.doc"));
            FileWriter c;
            myCharArray.writeTo(c=new FileWriter("TercerFichero.rtf"));
            FileWriter d;
            myCharArray.writeTo(d=new FileWriter("CuartoFichero.js"));
            System.out.println("Se han escrito los cuatro ficheros");
            a.close();b.close();c.close();d.close();
            /*
            * Una vez esta escrito, cerramos el CharArrayWriter con el metodo .close() pero como ya he comentado no tien efecto y puedo seguir trabajando con el
            */
            myCharArray.close();
            
        /*
        *  Podemos resetear el CharArrayWriter para poder trabajar de nuevo con el gracias al metodo .reset()   
        */
        myCharArray.reset();
        System.out.println("Se ha reseteado y el tamaño es: "+myCharArray.size());
            System.out.println("Contiene esto: "+myCharArray.toString());
            
            System.out.println("\n \nahora le añadimos al CharArrayWriter algo de nuevo");
            myCharArray.append("Hola Gente");
            System.out.println("Contiene esto: "+myCharArray.toString());
        
        
        
        } catch (IOException ex) {
            Logger.getLogger(MyCharArrayWriter.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
