/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pipedreaderwriter;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
/**
 *
 * @author Zuly
 */
public class PipedReaderWriter {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        final PipedReader pipedReader = new PipedReader();
      final PipedWriter pipedWriter = new PipedWriter();

      // Conecta el pipe
      pipedReader.connect(pipedWriter);

      // Escribe datos en el pipe
      Thread writerThread = new Thread(new Runnable() {
         @Override
         public void run() {
            try {
               for (int i = 65; i <= 75; i++) {
                  pipedWriter.write((char) i);
                  //detiene el proceso 500 milisegundos
                  Thread.sleep(500);
               }
               pipedWriter.close();
            } catch (IOException | InterruptedException e) {
               e.printStackTrace();
            }
         }
      });

      // Leyendo datos del pipe
      Thread readerThread = new Thread(new Runnable() {
         @Override
         public void run() {
            try {
               int i;
               while ((i = pipedReader.read()) != -1) {
                  System.out.println((char) i);
                  Thread.sleep(1000);
               }
               pipedReader.close();
            } catch (IOException | InterruptedException e) {
               e.printStackTrace();
            }
         }
      });

      // Empieza el hilo
      writerThread.start();
      readerThread.start();
    }
    
}
