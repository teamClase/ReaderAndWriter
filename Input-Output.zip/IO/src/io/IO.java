/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class IO {

    public static void main(String[] args) {

        /*El bloque inferior sirve para parar el programa y hacer una breve explicación al usuario.*/
        System.out.println("El siguiente ejemplo muestra la lectura de bytes de un archivo y lo muestra por pantalla./n");
        System.out.println("Pulsa 'Enter' para continuar al ejemplo.");
        Scanner lectura = new Scanner(System.in);
        String entrada = "";
        do {
            entrada = lectura.nextLine();            
        } while (!entrada.equals(""));
        
        /*
        Declaramos la variable donde se va a guardar cada linea que lea el BufferReader
        */
        String linea = null;
        try {
            /*
            Indicamos cual es la ruta en la que se encuentra el archivo que vamos a leer.
            */
            InputStream ruta = new FileInputStream("./Letras/Queen-Bohemian-Rhapsody.txt");
            /*
            Otorgamos al BufferedReader la lectura que realizamos del archivo mediante el InputStreamReader
            */
            BufferedReader buffer = new BufferedReader(new InputStreamReader(ruta));
            /*
            Provocamos un bucle que seguira funcionando mientras en nuestra variable "buffer" haya bytes leídos y lo msotramos por pantalla.
            */
            while (buffer.ready()) {
                // reads each line of file
                linea = buffer.readLine();
                System.out.println(linea);
            }
        } catch (IOException e) {

            e.printStackTrace();
        }

        /*El bloque inferior sirve para parar el programa y hacer una breve explicación al usuario.*/
        System.out.println("\n El ejemplo inferior mostrará como leer bytes por pantalla y mostrarlos.");
        System.out.println("Pulsa 'Enter' para continuar al ejemplo.");
        entrada = null;
        do {
            entrada = lectura.nextLine();            
        } while (!entrada.equals(""));
        
        /*
        El siguiente bloque permite un uso alternativo del InputStreamReader
        en el que leemos por pantalla una serie de bytes y los devuelve concatenados en una frase.
        */
        try {
            InputStreamReader a = new InputStreamReader(System.in);
            BufferedReader b = new BufferedReader(a);
            System.out.println("Escribe tu nombre: ");
            String nombre = b.readLine();
            System.out.println("Hola " + nombre);

        } catch (Exception e) {
            System.err.println(e);
        }

        /*El bloque inferior sirve para parar el programa y hacer una breve explicación al usuario.*/
        System.out.println("\n Se va a crear un archivo con una frase en el directorio raíz del programa.");
        System.out.println("Pulsa 'Enter' para continuar al ejemplo.");
        entrada = null;
        do {
            entrada = lectura.nextLine();            
        } while (!entrada.equals(""));
        
        /*
        Declaramos donde se va a crear nuestro archivo
        */
        File archivo = new File("./test.txt");

        /*
        Creamos una variable que va a tener el contenido del archivo, en este caso una frase.
        */
        String lines = "Soy el contenido del archivo";
        /*
        Declaramos una variable que será la encargada de escribir el contenido de "lines" en el archivo.
        */
        Writer salida = null;
        try {
            /*
            Introducimos en nuestra variable "Writer" mediante un Buffer, la ruta del archivo y la codificación del mismo (obligatorio).
            */
            salida = new BufferedWriter(
                    new OutputStreamWriter(
                            new FileOutputStream(archivo), "UTF-8"));
            /*
            Por último, escribimos las lineas en nuestra variable de salida.
            */
            salida.write(lines);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (salida != null) {
                try {
                    /*
                    Cerramos el archivo de escritura.
                    */
                    salida.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
