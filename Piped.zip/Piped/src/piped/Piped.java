/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piped;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;

/**
 *
 * @author amgal
 */
public class Piped {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        //Creamos el reader y el writter
        PipedReader ejemploReader=new PipedReader();
        PipedWriter ejemploWriter=new PipedWriter();
        
        //Conectamos el reader con el writer
        ejemploReader.connect(ejemploWriter);
        
        //Asignamos valores al writer 
        ejemploWriter.write('a');
        //Comprobamos si esta listo para ser leido
        if(ejemploReader.ready()){
            System.out.println("provando read() : " + /*debmos parsear a caracter*/(char)ejemploReader.read());
            ejemploWriter.write('b');
            System.out.println("provando read() : " + (char)ejemploReader.read());
            ejemploWriter.write('c');
            System.out.println("provando read() : " + (char)ejemploReader.read());
        }
        /*Ahora vamos a usar el otro metodo de ambas clases para escribir y leer arrys completos
        primero escribimos el array*/
        char[] test=new char[4];
        test[0]='T';
        test[1]='E';
        test[2]='t';
        test[3]='S';
        
        //creamos el array en el que guardaremos la informacion que vamos a leer
        char[] reader=new char[4];
        
        /*usamos el metodo write(char[] cbuf, int off, int len)
        cbuf es el array de caracteres
        off es la posicion desde la que se empiza a escribir los caracteres de dicho array
        len es la cantidad de caracteres que se escriben */
        ejemploWriter.write(test, 0, test.length);
        
        /*Ahora leeremos el arrray
        En el if nos aseguramos de que el pipedReader este listo para ser leido, 
        ademas con read() comprobamos que no este vacio el array nos devolvera -1*/
        if(ejemploReader.ready()){
            //read nos p    ermite cargar la informacion guardada con piped writer en un array vacio
            ejemploReader.read(reader,0,reader.length);
            for(int i=0;i<reader.length;i++){
                System.out.println(reader[i]);
            } 
        }
        
        //Cerramos los piped
        ejemploReader.close();
        ejemploWriter.close();
    }
    
}
